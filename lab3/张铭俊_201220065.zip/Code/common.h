#pragma once
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
//str to int ,can transfer dec,oct,hex
int stoi(const char *str);
//str to float ,can transfer sci
float stof(const char *str);