#pragma once
#include<stdarg.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"common.h"

extern int yylineno;
extern char* yytext;

int yyerror(char *msg);

typedef struct Node{
    int lineno;
    char* name;
    union{
        char* val;  //for TYPE and ID
        int type_int;//for INT
        float type_float;//for FLOAT
    };
    int iflexcial;
    struct Node* child;
    struct Node* nextsibling;
}tNode;

int iftrue;    //see if need to print the tree

tNode* firstNode;   //the first Node,to be the program
//tNode* nodelist[1000];
//int* ifchildnode[1000];
//int nodenum;

//int getnodelistId(tNode* node);


tNode* addNode(char* name,int num,...);
void dfs(tNode* head,int level);